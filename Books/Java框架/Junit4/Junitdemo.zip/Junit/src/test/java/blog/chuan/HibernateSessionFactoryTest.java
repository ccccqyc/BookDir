package blog.chuan;

import org.hibernate.internal.SessionFactoryImpl;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by q on 17-10-12.
 */
public class HibernateSessionFactoryTest {

    private static ApplicationContext context;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        context = new ClassPathXmlApplicationContext("spring-config.xml");

    }

    @Test
    public void getSessionFactory() throws Exception {
        SessionFactoryImpl sessionFactory = (SessionFactoryImpl) context.getBean("sessionFactory");
        System.out.println(sessionFactory);

    }


}