package blog.chuan;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * Unit test for simple App.
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({CalculateTest.class, HibernateSessionFactoryTest.class, ParameTest.class, SpringTest.class})
public class AppTest {

}
