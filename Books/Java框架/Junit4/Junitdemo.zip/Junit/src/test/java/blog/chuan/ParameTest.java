package blog.chuan;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import java.util.Arrays;
import java.util.Collection;

import static org.junit.Assert.assertEquals;

/**
 * Created by q on 17-10-11.
 */
@RunWith(Parameterized.class)
public class ParameTest {

    int expected = 0;
    int iput1 = 0;
    int iput2 = 0;

    @Parameters
    public static Collection<Integer[]> data() {
        return Arrays.asList(
                new Integer[]{1, 4, 3},
                new Integer[]{0, 5, 5}
        );
    }

    public ParameTest(int expected, int iput1, int iput2) {
        this.expected = expected;
        this.iput1 = iput1;
        this.iput2 = iput2;
    }

    @Test
    public void testSubstract(){
        assertEquals(expected,new Calculate().substract(iput1,iput2));
    }
}
