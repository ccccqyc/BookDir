package blog.chuan;

import org.junit.*;

import static org.junit.Assert.assertEquals;

/**
 * Created by q on 17-10-11.
 */
public class CalculateTest {

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        System.out.println("setupbefore");
    }

    @Before
    public void setUp() throws Exception {
        System.out.println("setup");
    }

    @Test
    public void substract() throws Exception {
        assertEquals(6, new Calculate().substract(9, 3));
    }

    @Test
    public void multi() throws Exception {
        assertEquals("乘法不对劲", 30, new Calculate().multi(5, 6));
    }

    @Test(expected = ArithmeticException.class)
    public void divide() throws Exception {
        assertEquals(3, new Calculate().divide(18, 0));
    }

    @Test(timeout = 200)
    public void testwhile() {
    }

    @Test
    public void add() throws Exception {
        System.out.println("ccc");
        assertEquals(11, new Calculate().add(5, 6));
    }

    @After
    public void tearDown() throws Exception {
        System.out.println("tearDown");
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
        System.out.println("teardownafterDown");
    }


}