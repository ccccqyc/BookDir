package json;

import bean.People;
import org.json.JSONObject;

import java.util.HashMap;

/**
 * Created by q on 17-10-12.
 */
public class JSONObjectSample {

    public static void main(String[] args) {
        jsonObject();
        createJSONByMap();
        createJSONByBean();
    }

    private static void jsonObject() {
        JSONObject wangxiaoer = new JSONObject();

        Object nullObj = null;
        wangxiaoer.put("name", "王小二");
        wangxiaoer.put("age", 25.2);
        wangxiaoer.put("birthday", "1990-10-01");
        wangxiaoer.put("school", "蓝翔");
        wangxiaoer.put("major", new String[]{"理发", "挖掘机"});
        wangxiaoer.put("has_girlfriend", nullObj);
        wangxiaoer.put("has_house", nullObj);
        wangxiaoer.put("car", nullObj);
        wangxiaoer.put("comment", "JSON 不支持任何形式的注释");

        System.out.println(wangxiaoer.toString());
    }

    private static void createJSONByMap(){
        HashMap<String,Object> wangxiaoer = new HashMap<>();

        Object nullObj = null;
        wangxiaoer.put("name", "王小二");
        wangxiaoer.put("age", 25.2);
        wangxiaoer.put("birthday", "1990-10-01");
        wangxiaoer.put("school", "蓝翔");
        wangxiaoer.put("major", new String[]{"理发", "挖掘机"});
        wangxiaoer.put("has_girlfriend", nullObj);
        wangxiaoer.put("has_house", nullObj);
        wangxiaoer.put("car", nullObj);
        wangxiaoer.put("comment", "JSON 不支持任何形式的注释");

        System.out.println(new JSONObject(wangxiaoer).toString());
    }

    private static void createJSONByBean(){
        People wangxiaoer = new People();
        wangxiaoer.setName("wangxiaoer");
        wangxiaoer.setAge(25.2);
        wangxiaoer.setBirthday("11900");
        wangxiaoer.setHas_girlfirend(false);
        wangxiaoer.setMajor(new String[]{"修车","做菜"});

        //需要get方法
        System.out.println(new JSONObject(wangxiaoer).toString());
    }
}
