package json;

import org.apache.commons.io.FileUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;

/**
 * Created by q on 17-10-12.
 */
public class ReadJSON {
    public static void main(String[] args) throws IOException {
        File path = new File("src/json/wangxiaoer.json");
        String content = FileUtils.readFileToString(path);
        JSONObject jsonObject = new JSONObject(content);
        System.out.println("姓名: " + jsonObject.getString("name"));
        System.out.println("年龄: " + jsonObject.getDouble("age"));

        if (!jsonObject.isNull("has_house")){
            System.out.println();
        }

        JSONArray array = jsonObject.getJSONArray("major");
        for (int i = 0; i < array.length(); i++) {
            String m = array.getString(i);
            System.out.println("专业 :　" + (i + 1) + m);
        }
    }

}
