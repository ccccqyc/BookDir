package gson;

import bean.People;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * Created by q on 17-10-12.
 */
public class GSONCreateSample {
    public static void main(String[] args) {
        People wangxiaoer = new People();
        wangxiaoer.setName("wangxiaoer");
        wangxiaoer.setAge(25.2);
        wangxiaoer.setBirthday("11900");
        wangxiaoer.setHas_girlfirend(false);
        wangxiaoer.setMajor(new String[]{"修车", "做菜"});

        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.setPrettyPrinting();
        gsonBuilder.setFieldNamingStrategy(field -> field.getName().toUpperCase());
        Gson gson = gsonBuilder.create();
        System.out.println(gson.toJson(wangxiaoer));
    }
}
