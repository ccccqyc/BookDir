package gson;

import bean.People;
import bean.PeopleDate;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Created by q on 17-10-12.
 */
public class GSONRead {
    public static void main(String[] args) throws IOException {
        File file = new File("src/json/wangxiaoer.json");
        String content = FileUtils.readFileToString(file);
        Gson gson = new Gson();
        People wangxiaoer = gson.fromJson(content, People.class);

        System.out.println(wangxiaoer);


        //带日期转换,将此格式"yyyy-MM-dd"装换成Date
        Gson gson2 = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
        PeopleDate wangxiaoer2 = gson2.fromJson(content, PeopleDate.class);
        List<String> major = wangxiaoer2.getMajor();
        System.out.println(wangxiaoer2.getBirthday().toLocaleString());
        System.out.println(wangxiaoer2);
        System.out.println("-------");
        System.out.println(wangxiaoer.getMajor());
        System.out.println(wangxiaoer.getMajor().getClass());
        System.out.println(wangxiaoer2.getMajor());
        System.out.println(wangxiaoer2.getMajor().getClass());
        }
}
