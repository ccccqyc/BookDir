package bean;

import java.util.Arrays;

/**
 * Created by q on 17-10-12.
 */
public class People {

    //    @SerializedName("CHUAN")
    private String name;
    private double age;
    private String birthday;
    private String school;
    private String[] major;
    private boolean has_girlfirend;
    private boolean has_house;
    private boolean car;
    private String comment;

    @Override
    public String toString() {
        return "People{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", birthday='" + birthday + '\'' +
                ", school='" + school + '\'' +
                ", major=" + Arrays.toString(major) +
                ", has_girlfirend=" + has_girlfirend +
                ", has_house=" + has_house +
                ", car=" + car +
                ", comment='" + comment + '\'' +
                '}';
    }

    public String[] getMajor() {
        return major;
    }

    public String getName() {
        return name;
    }

    public double getAge() {
        return age;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public void setHas_house(boolean has_house) {
        this.has_house = has_house;
    }

    public void setCar(boolean car) {
        this.car = car;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(double age) {
        this.age = age;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public void setMajor(String[] major) {
        this.major = major;
    }

    public void setHas_girlfirend(boolean has_girlfirend) {
        this.has_girlfirend = has_girlfirend;
    }

}

